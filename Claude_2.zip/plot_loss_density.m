%plot_loss_density
%{
function plot_loss_density(geom, results)

    fil = geom.filaments;
    P   = results.P_fil;

    figure; hold on; axis equal; box on;
    title('Copper Loss Density (W/m^2)');
    xlabel('x (m)');
    ylabel('y (m)');

    pdens = P ./ (fil(:,3).*fil(:,4));
    pmax  = max(pdens);

    cmap = hot(256);

    for i = 1:length(pdens)
        cidx = max(1, round(255*pdens(i)/pmax));
        rectangle( ...
            'Position',[ ...
                fil(i,1)-fil(i,3)/2, ...
                fil(i,2)-fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(hot);
    colorbar;

    hold on;
    hs = identify_hotspots(geom, results, 5);
    for k = 1:length(hs)
        plot(hs(k).x, hs(k).y,'rx','MarkerSize',12,'LineWidth',2);
    end
    hold off;

end
%}
%{
% plot_loss_density.m
function plot_loss_density(geom_A, results)

    fil = geom_A.filaments;
    P   = results.P_fil;

    hold on;
    axis equal;
    box on;

  %  title('Copper Loss Density (W/m^2)');
    xlabel('x (m)');
    ylabel('y (m)');

    pdens = P ./ (fil(:,3) .* fil(:,4));
    pmax  = max(pdens);

    cmap = hot(256);

    for i = 1:length(pdens)
        cidx = max(1, round(255 * pdens(i) / pmax));
        rectangle( ...
            'Position', [ ...
                fil(i,1) - fil(i,3)/2, ...
                fil(i,2) - fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor', 'none');
    end

    colormap(hot);
    colorbar;

    % ---- Hotspots overlay ----
    hs = identify_hotspots(geom_A, results, 5);
    for k = 1:length(hs)
        plot(hs(k).x, hs(k).y, ...
            'rx', 'MarkerSize', 12, 'LineWidth', 2);
    end

end


function plot_loss_density(geom, results)

    fil = geom.filaments;
    P   = results.P_fil;

    hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    pdens = P ./ (fil(:,3) .* fil(:,4));
    pmax  = max(pdens);

    cmap = hot(256);

    for i = 1:length(pdens)
        cidx = max(1, round(255 * pdens(i) / pmax));
        rectangle( ...
            'Position',[ ...
                fil(i,1) - fil(i,3)/2, ...
                fil(i,2) - fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(hot);
    colorbar;

    hs = identify_hotspots(geom, results, 5);
    for k = 1:length(hs)
        plot(hs(k).x, hs(k).y, 'rx', ...
            'MarkerSize', 12, 'LineWidth', 2);
    end
end


% plot_loss_density.m - Fixed for correct filament array format
function plot_loss_density(geom, results)

    fil = geom.filaments;
    P   = results.P_fil;

    hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    % Calculate power density
    % fil columns: [x, y, dx, dy, conductor_idx, I_complex]
    pdens = P ./ (fil(:,3) .* fil(:,4));
    pmax  = max(pdens);

    cmap = hot(256);

    for i = 1:length(pdens)
        cidx = max(1, round(255 * pdens(i) / pmax));
        rectangle( ...
            'Position',[ ...
                fil(i,1) - fil(i,3)/2, ...
                fil(i,2) - fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(hot);
    cb = colorbar;
    ylabel(cb, 'Power Density (W/m^2)');

    % Set colorbar limits
    caxis([0 pmax]);

    % Overlay hotspots
    hs = identify_hotspots(geom, results, 5);
    for k = 1:length(hs)
        plot(hs(k).x, hs(k).y, 'rx', ...
            'MarkerSize', 12, 'LineWidth', 2);
    end
end
%}

% plot_loss_density.m - Fixed for correct filament array format
function plot_loss_density(geom, results)

    fil = geom.filaments;
    P   = results.P_fil;

    hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    % Calculate power density
    % fil columns: [x, y, dx, dy, conductor_idx, winding_idx, I_complex]
    pdens = P ./ (fil(:,3) .* fil(:,4));
    pmax  = max(pdens);

    cmap = hot(256);

    for i = 1:length(pdens)
        cidx = max(1, round(255 * pdens(i) / pmax));
        rectangle( ...
            'Position',[ ...
                fil(i,1) - fil(i,3)/2, ...
                fil(i,2) - fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(hot);
    cb = colorbar;
    ylabel(cb, 'Power Density (W/m^2)');

    % Set colorbar limits
    caxis([0 pmax]);

    % Overlay hotspots
    hs = identify_hotspots(geom, results, 5);
    for k = 1:length(hs)
        plot(hs(k).x, hs(k).y, 'rx', ...
            'MarkerSize', 12, 'LineWidth', 2);
    end
end
