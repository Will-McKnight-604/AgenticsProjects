%build_transformer_geometry
function [conductors, winding_map] = build_transformer_geometry(winding_config, width, height, gap_layer, gap_turn)
% Build transformer geometry with multiple windings, layers, and turns
%
% Inputs:
%   winding_config - Cell array defining each winding:
%                    {winding_id, N_turns, N_layers, I_rms, phase_deg}
%                    Example: {1, 10, 2, 5.0, 0} = Primary with 10 turns in 2 layers
%                             {2, 20, 4, 2.5, 180} = Secondary with 20 turns in 4 layers
%   width         - Conductor width [m]
%   height        - Conductor height [m]
%   gap_layer     - Gap between layers [m]
%   gap_turn      - Gap between turns within a layer [m]
%
% Outputs:
%   conductors    - [N_conductors x 6] array: [x, y, width, height, I, phase]
%   winding_map   - Structure mapping conductors to windings and turns

    N_windings = length(winding_config);
    conductors = [];

    % Initialize winding map
    winding_map.winding_id = [];      % Which winding (e.g., primary=1, secondary=2)
    winding_map.turn_num = [];        % Which turn within that winding
    winding_map.layer_num = [];       % Which layer
    winding_map.conductor_idx = [];   % Index in conductors array

    conductor_idx = 0;
    y_position = 0;  % Start position

    for w = 1:N_windings
        winding_id = winding_config{w}{1};
        N_turns    = winding_config{w}{2};
        N_layers   = winding_config{w}{3};
        I_rms      = winding_config{w}{4};
        phase_deg  = winding_config{w}{5};

        % Distribute turns across layers
        % Strategy: round-robin distribution
        turns_per_layer = floor(N_turns / N_layers);
        extra_turns = mod(N_turns, N_layers);

        turn_counter = 0;

        for layer = 1:N_layers
            % How many turns in this layer?
            if layer <= extra_turns
                turns_this_layer = turns_per_layer + 1;
            else
                turns_this_layer = turns_per_layer;
            end

            for turn = 1:turns_this_layer
                turn_counter = turn_counter + 1;
                conductor_idx = conductor_idx + 1;

                % Position: stack turns vertically within each layer
                x_pos = 0;  % All conductors aligned (can modify for interleaving)
                y_pos = y_position;

                % Add conductor
                conductors = [conductors;
                             x_pos, y_pos, width, height, I_rms, phase_deg];

                % Map this conductor
                winding_map.winding_id(conductor_idx) = winding_id;
                winding_map.turn_num(conductor_idx) = turn_counter;
                winding_map.layer_num(conductor_idx) = layer;
                winding_map.conductor_idx(conductor_idx) = conductor_idx;

                % Move to next turn position
                y_position = y_position + height + gap_turn;
            end

            % Add layer gap (except after last layer of last winding)
            if ~(w == N_windings && layer == N_layers)
                y_position = y_position - gap_turn + gap_layer;
            end
        end
    end

    % Convert to column vectors for consistency
    winding_map.winding_id = winding_map.winding_id(:);
    winding_map.turn_num = winding_map.turn_num(:);
    winding_map.layer_num = winding_map.layer_num(:);
    winding_map.conductor_idx = winding_map.conductor_idx(:);

    % Store configuration for reference
    winding_map.config = winding_config;
end
