%plot_current_density
%{
function plot_current_density(geom, results)

    fil = geom.filaments;
    I   = results.I_fil;

    figure; hold on; axis equal; box on;
    title('Current Density Magnitude');
    xlabel('x (m)');
    ylabel('y (m)');

    Jmag = abs(I) ./ (fil(:,3).*fil(:,4));

    Jmax = max(Jmag);
    cmap = jet(256);

    for i = 1:length(Jmag)
        cidx = max(1, round(255*Jmag(i)/Jmax));
        rectangle( ...
            'Position',[ ...
                fil(i,1)-fil(i,3)/2, ...
                fil(i,2)-fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(jet);
    colorbar;
end
%}
%{
% plot_current_density.m  (Octave-compatible, slider-safe)
function plot_current_density(geom_A, results)

    fil = geom_A.filaments;
    I   = results.I_fil;

    hold on;
    axis equal;
    box on;

    title('Current Density Magnitude');
    xlabel('x (m)');
    ylabel('y (m)');

    Jmag = abs(I) ./ (fil(:,3) .* fil(:,4));

    Jmax = max(Jmag);
    cmap = jet(256);

    for i = 1:length(Jmag)
        cidx = max(1, round(255 * Jmag(i) / Jmax));
        rectangle( ...
            'Position', [ ...
                fil(i,1) - fil(i,3)/2, ...
                fil(i,2) - fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor', 'none');
    end

    colormap(jet);
    colorbar;

end


function plot_current_density(geom, results)

    fil = geom.filaments;
    I   = results.I_fil;

    cla; hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    Jmag = abs(I) ./ (fil(:,3).*fil(:,4));
    Jmax = max(Jmag);

    cmap = jet(256);

    for i = 1:length(Jmag)
        cidx = max(1, round(255 * Jmag(i) / Jmax));
        rectangle( ...
            'Position', [ ...
                fil(i,1)-fil(i,3)/2, ...
                fil(i,2)-fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(jet);
    colorbar;
end
%}
%{
%plot_current_density
function plot_current_density(geom, results)
    fil = geom.filaments;
    I   = results.I_fil;

    cla; hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    Jmag = abs(I) ./ (fil(:,3).*fil(:,4));

    % Use patch instead of rectangle loop for 10-20x speedup
    [vertices, faces, colors] = create_patch_data(fil, Jmag);

    patch('Vertices', vertices, 'Faces', faces, ...
          'FaceVertexCData', colors, ...
          'FaceColor', 'flat', ...
          'EdgeColor', 'none');

    colormap(jet);
    colorbar;
end

%plot_loss_density
function plot_loss_density(geom, results)
    fil = geom.filaments;
    P   = results.P_fil;

    cla; hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    pdens = P ./ (fil(:,3) .* fil(:,4));

    % Use patch instead of rectangle loop
    [vertices, faces, colors] = create_patch_data(fil, pdens);

    patch('Vertices', vertices, 'Faces', faces, ...
          'FaceVertexCData', colors, ...
          'FaceColor', 'flat', ...
          'EdgeColor', 'none');

    colormap(hot);
    colorbar;

    hs = identify_hotspots(geom, results, 5);
    for k = 1:length(hs)
        plot(hs(k).x, hs(k).y, 'rx', ...
            'MarkerSize', 12, 'LineWidth', 2);
    end
end

% Helper function for creating patch data
function [vertices, faces, colors] = create_patch_data(fil, density)
    Nf = size(fil, 1);

    % Pre-allocate arrays
    vertices = zeros(4*Nf, 2);
    faces = zeros(Nf, 4);

    % Normalize density for colormap
    density_norm = density / max(density);
    colors = density_norm;

    % Build vertices and faces
    for i = 1:Nf
        x_center = fil(i,1);
        y_center = fil(i,2);
        dx = fil(i,3);
        dy = fil(i,4);

        % Four corners of rectangle
        v_idx = (i-1)*4 + 1;
        vertices(v_idx:v_idx+3, :) = [
            x_center - dx/2, y_center - dy/2;
            x_center + dx/2, y_center - dy/2;
            x_center + dx/2, y_center + dy/2;
            x_center - dx/2, y_center + dy/2
        ];

        % Face connectivity
        faces(i, :) = v_idx:v_idx+3;
    end
end


% plot_current_density.m - Fixed for correct filament array format
function plot_current_density(geom, results)

    fil = geom.filaments;
    I   = results.I_fil;

    cla; hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    % Calculate current density magnitude
    % fil columns: [x, y, dx, dy, conductor_idx, I_complex]
    Jmag = abs(I) ./ (fil(:,3).*fil(:,4));
    Jmax = max(Jmag);

    cmap = jet(256);

    for i = 1:length(Jmag)
        cidx = max(1, round(255 * Jmag(i) / Jmax));
        rectangle( ...
            'Position', [ ...
                fil(i,1)-fil(i,3)/2, ...
                fil(i,2)-fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(jet);
    cb = colorbar;
    ylabel(cb, 'Current Density (A/m^2)');

    % Set colorbar limits
    caxis([0 Jmax]);
end
%}

% plot_current_density.m - Fixed for correct filament array format
function plot_current_density(geom, results)

    fil = geom.filaments;
    I   = results.I_fil;

    cla; hold on;
    axis equal;
    box on;

    xlabel('x (m)');
    ylabel('y (m)');

    % Calculate current density magnitude
    % fil columns: [x, y, dx, dy, conductor_idx, winding_idx, I_complex]
    Jmag = abs(I) ./ (fil(:,3).*fil(:,4));
    Jmax = max(Jmag);

    cmap = jet(256);

    for i = 1:length(Jmag)
        cidx = max(1, round(255 * Jmag(i) / Jmax));
        rectangle( ...
            'Position', [ ...
                fil(i,1)-fil(i,3)/2, ...
                fil(i,2)-fil(i,4)/2, ...
                fil(i,3), fil(i,4)], ...
            'FaceColor', cmap(cidx,:), ...
            'EdgeColor','none');
    end

    colormap(jet);
    cb = colorbar;
    ylabel(cb, 'Current Density (A/m^2)');

    % Set colorbar limits
    caxis([0 Jmax]);
end
