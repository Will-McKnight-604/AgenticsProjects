% interactive_winding_designer.m
% Interactive GUI for designing multi-filar transformer windings
%{
function interactive_winding_designer()

    close all;

    % Initialize global data structure
    data = struct();

    % Default transformer configuration
    data.n_windings = 2;
    data.winding_names = {'Primary', 'Secondary'};
    data.winding_colors = {[0.2 0.4 0.8], [0.8 0.2 0.2]};

    % Default winding parameters
    data.windings(1).name = 'Primary';
    data.windings(1).n_turns = 10;
    data.windings(1).n_filar = 1;
    data.windings(1).current = 10;
    data.windings(1).phase = 0;

    data.windings(2).name = 'Secondary';
    data.windings(2).n_turns = 5;
    data.windings(2).n_filar = 1;
    data.windings(2).current = 5;
    data.windings(2).phase = 180;

    % Geometry parameters
    data.width = 2e-3;
    data.height = 1e-3;
    data.gap_layer = 0.2e-3;
    data.gap_filar = 0.15e-3;
    data.gap_winding = 1e-3;

    % Analysis parameters
    data.sigma = 5.8e7;
    data.mu0 = 4*pi*1e-7;
    data.f = 100e3;
    data.Nx = 6;
    data.Ny = 6;

    % Create main GUI figure
    data.fig_gui = figure('Name', 'Interactive Winding Designer', ...
                          'Position', [50 100 1200 700], ...
                          'NumberTitle', 'off', ...
                          'MenuBar', 'none', ...
                          'Resize', 'off');

    % Create results figure (initially hidden)
    data.fig_results = [];

    % Build GUI layout
    build_gui(data);

    % Initial visualization
    update_visualization(data);
end

function build_gui(data)

    fig = data.fig_gui;

    % Main title
    uicontrol('Parent', fig, 'Style', 'text', ...
              'String', 'Interactive Transformer Winding Designer', ...
              'Position', [20 660 1160 30], ...
              'FontSize', 14, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center');

    % Left panel - Tabbed controls
    tab_panel = uipanel('Parent', fig, ...
                        'Position', [0.02 0.15 0.48 0.8], ...
                        'Title', 'Winding Configuration');

    % Create tabs using button group
    tab_group = uibuttongroup('Parent', tab_panel, ...
                              'Position', [0.02 0.85 0.96 0.12], ...
                              'BorderType', 'none');

    % Tab buttons
    for w = 1:data.n_windings
        uicontrol('Parent', tab_group, 'Style', 'togglebutton', ...
                  'String', data.windings(w).name, ...
                  'Position', [10 + (w-1)*120, 5, 110, 30], ...
                  'Tag', sprintf('tab%d', w), ...
                  'Callback', {@switch_tab, w});
    end

    % Set first tab as selected
    set(findobj(tab_group, 'Tag', 'tab1'), 'Value', 1);

    % Content panels for each winding (initially all hidden)
    for w = 1:data.n_windings
        panel = uipanel('Parent', tab_panel, ...
                        'Position', [0.02 0.02 0.96 0.8], ...
                        'Visible', 'off', ...
                        'Tag', sprintf('content%d', w));

        % Winding name
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', sprintf('%s Winding', data.windings(w).name), ...
                  'Position', [20 380 300 25], ...
                  'FontSize', 12, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        % Number of turns control
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Number of Turns:', ...
                  'Position', [20 330 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_dec_%d', w), ...
                  'Callback', {@adjust_turns, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_turns), ...
                  'Position', [215 330 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('turns_val_%d', w), ...
                  'Callback', {@update_turns_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_inc_%d', w), ...
                  'Callback', {@adjust_turns, w, 1});

        % Number of parallel strands (filar)
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Parallel Strands (Filar):', ...
                  'Position', [20 280 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_dec_%d', w), ...
                  'Callback', {@adjust_filar, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_filar), ...
                  'Position', [215 280 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('filar_val_%d', w), ...
                  'Callback', {@update_filar_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_inc_%d', w), ...
                  'Callback', {@adjust_filar, w, 1});

        % Filar type label
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', get_filar_name(data.windings(w).n_filar), ...
                  'Position', [310 280 150 25], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left', ...
                  'ForegroundColor', [0.2 0.6 0.2], ...
                  'Tag', sprintf('filar_name_%d', w));

        % Current settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'RMS Current (A):', ...
                  'Position', [20 230 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).current), ...
                  'Position', [180 230 80 25], ...
                  'Tag', sprintf('current_%d', w), ...
                  'Callback', {@update_current, w});

        % Phase settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Phase (degrees):', ...
                  'Position', [20 180 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).phase), ...
                  'Position', [180 180 80 25], ...
                  'Tag', sprintf('phase_%d', w), ...
                  'Callback', {@update_phase, w});

        % Summary info
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Configuration Summary:', ...
                  'Position', [20 120 300 20], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
            data.windings(w).n_turns * data.windings(w).n_filar, ...
            data.windings(w).current / data.windings(w).n_filar);

        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', summary_str, ...
                  'Position', [20 60 300 50], ...
                  'HorizontalAlignment', 'left', ...
                  'Tag', sprintf('summary_%d', w));
    end

    % Show first panel
    set(findobj(tab_panel, 'Tag', 'content1'), 'Visible', 'on');

    % Right panel - Visualization
    vis_panel = uipanel('Parent', fig, ...
                        'Position', [0.52 0.15 0.46 0.8], ...
                        'Title', 'Winding Layout Visualization');

    % Axes for visualization
    ax = axes('Parent', vis_panel, ...
              'Position', [0.1 0.1 0.85 0.8], ...
              'Tag', 'vis_axes');

    % Bottom buttons
    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Run Analysis', ...
              'Position', [450 50 150 40], ...
              'FontSize', 12, 'FontWeight', 'bold', ...
              'BackgroundColor', [0.2 0.7 0.3], ...
              'ForegroundColor', 'w', ...
              'Callback', @run_analysis);

    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Reset to Defaults', ...
              'Position', [620 50 150 40], ...
              'FontSize', 11, ...
              'Callback', @reset_defaults);

    % Store data in figure
    guidata(fig, data);
end

function switch_tab(~, ~, tab_num)
    fig = gcbf;
    data = guidata(fig);

    % Hide all content panels
    for w = 1:data.n_windings
        set(findobj(fig, 'Tag', sprintf('content%d', w)), 'Visible', 'off');
    end

    % Show selected panel
    set(findobj(fig, 'Tag', sprintf('content%d', tab_num)), 'Visible', 'on');
end

function adjust_turns(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, data.windings(winding).n_turns + delta);
    data.windings(winding).n_turns = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('turns_val_%d', winding)), 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function adjust_filar(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, min(4, data.windings(winding).n_filar + delta));
    data.windings(winding).n_filar = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('filar_val_%d', winding)), 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_turns_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, new_val);

    data.windings(winding).n_turns = new_val;
    set(src, 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_filar_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, min(4, new_val));

    data.windings(winding).n_filar = new_val;
    set(src, 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_current(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).current = str2double(get(src, 'String'));
    update_summary(fig, data, winding);
    guidata(fig, data);
end

function update_phase(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).phase = str2double(get(src, 'String'));
    guidata(fig, data);
end

function update_summary(fig, data, winding)
    summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
        data.windings(winding).n_turns * data.windings(winding).n_filar, ...
        data.windings(winding).current / data.windings(winding).n_filar);

    set(findobj(fig, 'Tag', sprintf('summary_%d', winding)), 'String', summary_str);
end

function update_visualization(data)
    fig = data.fig_gui;
    ax = findobj(fig, 'Tag', 'vis_axes');

    cla(ax);
    hold(ax, 'on');
    axis(ax, 'equal');
    grid(ax, 'on');

    x_offset = 0;

    for w = 1:data.n_windings
        n_turns = data.windings(w).n_turns;
        n_filar = data.windings(w).n_filar;

        % Calculate winding width
        if n_filar == 1
            winding_width = data.width;
        else
            winding_width = n_filar * data.width + (n_filar - 1) * data.gap_filar;
        end

        % Draw each turn
        for turn = 1:n_turns
            y_pos = (turn - 1) * (data.height + data.gap_layer);

            % Draw filar conductors
            for filar = 1:n_filar
                if n_filar == 1
                    x_pos = x_offset;
                else
                    x_start = x_offset - winding_width/2 + data.width/2;
                    x_pos = x_start + (filar - 1) * (data.width + data.gap_filar);
                end

                % Draw rectangle
                rectangle(ax, 'Position', [x_pos - data.width/2, y_pos, data.width, data.height], ...
                    'FaceColor', data.winding_colors{w}, ...
                    'EdgeColor', 'k', 'LineWidth', 0.5);
            end
        end

        % Add winding label
        max_y = n_turns * (data.height + data.gap_layer);
        text(ax, x_offset, max_y + 0.5e-3, data.windings(w).name, ...
            'HorizontalAlignment', 'center', 'FontWeight', 'bold', ...
            'FontSize', 10, 'Color', data.winding_colors{w});

        % Add info text
        info_str = sprintf('%d turns\n%s', n_turns, get_filar_name(n_filar));
        text(ax, x_offset, -0.8e-3, info_str, ...
            'HorizontalAlignment', 'center', 'FontSize', 8);

        % Move to next winding position
        x_offset = x_offset + winding_width/2 + data.gap_winding + ...
                   (w < data.n_windings) * (data.width * data.windings(w+1).n_filar + ...
                   (data.windings(w+1).n_filar - 1) * data.gap_filar) / 2;
    end

    xlabel(ax, 'X Position (m)');
    ylabel(ax, 'Y Position (m)');
    title(ax, 'Transformer Winding Layout');
    hold(ax, 'off');
end

function run_analysis(~, ~)
    fig = gcbf;
    data = guidata(fig);

    fprintf('\n=== RUNNING ANALYSIS ===\n');

    % Build conductors for all windings
    all_conductors = [];
    all_winding_map = [];
    x_offset = 0;

    for w = 1:data.n_windings
        config.n_filar = data.windings(w).n_filar;
        config.n_turns = data.windings(w).n_turns;
        config.n_windings = 1;
        config.width = data.width;
        config.height = data.height;
        config.gap_layer = data.gap_layer;
        config.gap_filar = data.gap_filar;
        config.currents = data.windings(w).current;
        config.phases = data.windings(w).phase;
        config.x_offset = x_offset;

        [cond, map] = build_multifilar_winding(config);

        all_conductors = [all_conductors; cond];
        all_winding_map = [all_winding_map; map + (w-1)];

        % Update x_offset for next winding
        if w < data.n_windings
            if config.n_filar == 1
                w_width = data.width;
            else
                w_width = config.n_filar * data.width + (config.n_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + w_width/2 + data.gap_winding;

            next_filar = data.windings(w+1).n_filar;
            if next_filar == 1
                next_width = data.width;
            else
                next_width = next_filar * data.width + (next_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + next_width/2;
        end
    end

    % Build geometry and solve
    fprintf('Building geometry...\n');
    geom = peec_build_geometry(all_conductors, data.sigma, data.mu0, data.Nx, data.Ny, all_winding_map);

    fprintf('Solving at %.0f kHz...\n', data.f/1e3);
    results = peec_solve_frequency(geom, all_conductors, data.f, data.sigma, data.mu0);

    % Display results in new figure
    display_results(data, geom, all_conductors, all_winding_map, results);
end

function display_results(data, geom, conductors, winding_map, results)
    % Create or reuse results figure
    if isempty(data.fig_results) || ~ishandle(data.fig_results)
        data.fig_results = figure('Name', 'Analysis Results', 'Position', [100 50 1400 900]);
    else
        figure(data.fig_results);
        clf;
    end

    % Calculate per-winding losses
    fils_per_cond = data.Nx * data.Ny;
    winding_losses = zeros(data.n_windings, 1);
    winding_Rdc = zeros(data.n_windings, 1);
    winding_Pdc = zeros(data.n_windings, 1);

    cond_offset = 0;
    for w = 1:data.n_windings
        n_cond_in_winding = data.windings(w).n_turns * data.windings(w).n_filar;

        for c = 1:n_cond_in_winding
            idx_start = (cond_offset + c - 1) * fils_per_cond + 1;
            idx_end = (cond_offset + c) * fils_per_cond;
            winding_losses(w) = winding_losses(w) + sum(results.P_fil(idx_start:idx_end));
        end

        cond_offset = cond_offset + n_cond_in_winding;

        % DC loss
        A = data.width * data.height;
        winding_Rdc(w) = (data.windings(w).n_turns / data.windings(w).n_filar) / (data.sigma * A);
        winding_Pdc(w) = 0.5 * data.windings(w).current^2 * winding_Rdc(w);
    end

    % Main title
    annotation('textbox', [0 0.96 1 0.04], ...
        'String', sprintf('Analysis Results @ %.0f kHz', data.f/1e3), ...
        'EdgeColor', 'none', 'HorizontalAlignment', 'center', ...
        'FontSize', 14, 'FontWeight', 'bold');

    % Current density
    subplot(2,3,1);
    plot_current_density(geom, results);
    title('Current Density');

    % Loss density
    subplot(2,3,2);
    plot_loss_density(geom, results);
    title('Loss Density');

    % Per-winding loss comparison
    subplot(2,3,3);
    bar([winding_Pdc, winding_losses]*1e3);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('Loss (mW)');
    legend('DC Loss', 'AC Loss', 'Location', 'best');
    title('Winding Loss Comparison');
    grid on;

    % Rac/Rdc by winding
    subplot(2,3,4);
    rac_rdc = winding_losses ./ winding_Pdc;
    bar(rac_rdc);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('R_{AC}/R_{DC}');
    title('AC Resistance Factor');
    grid on;

    % Summary table
    subplot(2,3,5);
    axis off;

    text(0.05, 0.95, 'Loss Summary', 'FontSize', 12, 'FontWeight', 'bold');
    y_pos = 0.85;

    for w = 1:data.n_windings
        text(0.05, y_pos, sprintf('%s:', data.windings(w).name), ...
            'FontSize', 10, 'FontWeight', 'bold', 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;

        text(0.05, y_pos, sprintf('  Config: %d turns, %s', ...
            data.windings(w).n_turns, get_filar_name(data.windings(w).n_filar)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  DC Loss: %.4f W', winding_Pdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  AC Loss: %.4f W', winding_losses(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  Rac/Rdc: %.2f', rac_rdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.12;
    end

    text(0.05, y_pos, sprintf('Total Loss: %.4f W', results.P_total), ...
        'FontSize', 11, 'FontWeight', 'bold');

    % Configuration visualization
    subplot(2,3,6);
    axis off;
    text(0.05, 0.95, 'Configuration', 'FontSize', 12, 'FontWeight', 'bold');

    y_pos = 0.85;
    for w = 1:data.n_windings
        filar_str = get_filar_name(data.windings(w).n_filar);
        text(0.05, y_pos, sprintf('%s: %d × %s', ...
            data.windings(w).name, data.windings(w).n_turns, filar_str), ...
            'FontSize', 9, 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;
    end

    fprintf('\n=== ANALYSIS COMPLETE ===\n');
    fprintf('Total loss: %.6f W\n', results.P_total);
end

function reset_defaults(~, ~)
    close all;
    interactive_winding_designer();
end

function name = get_filar_name(n)
    names = {'Single-filar', 'Bi-filar', 'Tri-filar', 'Quad-filar'};
    name = names{n};
end

%}

% build_multifilar_winding.m
% Build multi-filar winding configurations
% Fills vertically first, then adds horizontal columns when Y-limit reached
%{
function [conductors, winding_map] = build_multifilar_winding(config)
% Build multi-filar winding configuration
%
% INPUT:
%   config - Structure with fields:
%     .n_filar      - Number of parallel strands (1-4)
%     .n_turns      - Total number of turns per winding
%     .n_windings   - Number of separate windings (e.g., 2 for transformer)
%     .width        - Conductor width (m)
%     .height       - Conductor height (m)
%     .gap_layer    - Gap between vertical layers (m)
%     .gap_filar    - Gap between horizontal filar columns (m)
%     .gap_winding  - Gap between different windings in x-direction (m)
%     .currents     - [n_windings × 1] Current magnitude for each winding (Arms)
%     .phases       - [n_windings × 1] Phase angle for each winding (degrees)
%     .x_offset     - [n_windings × 1] X-position offset for each winding (m)
%     .max_y        - (optional) Maximum Y extent before starting new column (m)
%
% OUTPUT:
%   conductors   - [N × 6] array: [x, y, width, height, current, phase]
%   winding_map  - [N × 1] array: which winding each conductor belongs to
%
% LAYOUT STRATEGY (vertical-first filling):
%   Column 1: All n_turns stacked vertically (up to max_y)
%   Column 2: All n_turns stacked vertically (if n_filar >= 2)
%   Column 3: All n_turns stacked vertically (if n_filar >= 3)
%   Column 4: All n_turns stacked vertically (if n_filar >= 4)

    % ========== VALIDATE INPUTS ==========
    required_fields = {'n_filar', 'n_turns', 'n_windings', 'width', 'height', ...
                       'gap_layer', 'currents', 'phases'};

    for i = 1:length(required_fields)
        if ~isfield(config, required_fields{i})
            error('Missing required field: %s', required_fields{i});
        end
    end

    % Set defaults
    if ~isfield(config, 'gap_filar')
        config.gap_filar = config.gap_layer;  % Default: same as layer gap
    end

    if ~isfield(config, 'gap_winding')
        config.gap_winding = config.width + 1e-3;  % Default: 1mm gap
    end

    if ~isfield(config, 'x_offset')
        config.x_offset = zeros(config.n_windings, 1);
    end

    if ~isfield(config, 'max_y')
        % Default: allow all turns in one column (no Y limit)
        config.max_y = inf;
    end

    % Validate n_filar
    if config.n_filar < 1 || config.n_filar > 4
        error('n_filar must be 1, 2, 3, or 4');
    end

    % ========== BUILD CONDUCTORS ==========
    conductors = [];
    winding_map = [];

    for w = 1:config.n_windings

        x_base = config.x_offset(w);
        I_mag = config.currents(w);
        phase = config.phases(w);

        % Current is divided equally among all filar strands
        I_filar = I_mag / config.n_filar;

        % Layout strategy: Fill vertically first, then add columns
        % Each column contains all turns stacked vertically

        for column = 1:config.n_filar

            % Calculate x position for this column
            if config.n_filar == 1
                % Single column - centered
                x_pos = x_base;
            else
                % Multiple columns - spread horizontally from center
                total_width = config.n_filar * config.width + ...
                              (config.n_filar - 1) * config.gap_filar;
                x_start = x_base - total_width/2 + config.width/2;
                x_pos = x_start + (column - 1) * (config.width + config.gap_filar);
            end

            % Fill this column vertically with all turns
            for turn = 1:config.n_turns

                % Calculate y position for this turn
                y_pos = (turn - 1) * (config.height + config.gap_layer);

                % Check if we've exceeded Y limit
                if y_pos > config.max_y
                    % In future: could implement wrapping to new column
                    % For now: just continue (unlimited Y)
                end

                % Add conductor
                conductors = [conductors; ...
                    x_pos, y_pos, config.width, config.height, I_filar, phase];

                winding_map = [winding_map; w];
            end
        end
    end

    % ========== SUMMARY ==========
    fprintf('Multi-filar winding configuration:\n');
    fprintf('  Configuration: %d-filar (%d columns)\n', config.n_filar, config.n_filar);
    fprintf('  Number of windings: %d\n', config.n_windings);
    fprintf('  Turns per winding: %d\n', config.n_turns);
    fprintf('  Layout: %d columns × %d turns (vertical-first fill)\n', ...
        config.n_filar, config.n_turns);
    fprintf('  Total conductors: %d\n', size(conductors, 1));

    for w = 1:config.n_windings
        n_cond_in_winding = sum(winding_map == w);
        fprintf('  Winding %d: %d conductors, %.2f A total (%.2f A per column)\n', ...
            w, n_cond_in_winding, config.currents(w), I_filar);
    end
end
%}

% interactive_winding_designer.m
% Interactive GUI for designing multi-filar transformer windings
%{
function interactive_winding_designer()

    close all;

    % Initialize global data structure
    data = struct();

    % Default transformer configuration
    data.n_windings = 2;
    data.winding_names = {'Primary', 'Secondary'};
    data.winding_colors = {[0.2 0.4 0.8], [0.8 0.2 0.2]};

    % Default winding parameters
    data.windings(1).name = 'Primary';
    data.windings(1).n_turns = 10;
    data.windings(1).n_filar = 1;
    data.windings(1).current = 10;
    data.windings(1).phase = 0;

    data.windings(2).name = 'Secondary';
    data.windings(2).n_turns = 5;
    data.windings(2).n_filar = 1;
    data.windings(2).current = 5;
    data.windings(2).phase = 180;

    % Geometry parameters
    data.width = 2e-3;
    data.height = 1e-3;
    data.gap_layer = 0.2e-3;
    data.gap_filar = 0.15e-3;
    data.gap_winding = 1e-3;

    % Analysis parameters
    data.sigma = 5.8e7;
    data.mu0 = 4*pi*1e-7;
    data.f = 100e3;
    data.Nx = 6;
    data.Ny = 6;

    % Create main GUI figure
    data.fig_gui = figure('Name', 'Interactive Winding Designer', ...
                          'Position', [50 100 1200 700], ...
                          'NumberTitle', 'off', ...
                          'MenuBar', 'none', ...
                          'Resize', 'off');

    % Create results figure (initially hidden)
    data.fig_results = [];

    % Build GUI layout
    build_gui(data);

    % Initial visualization
    update_visualization(data);
end

function build_gui(data)

    fig = data.fig_gui;

    % Main title
    uicontrol('Parent', fig, 'Style', 'text', ...
              'String', 'Interactive Transformer Winding Designer', ...
              'Position', [20 660 1160 30], ...
              'FontSize', 14, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center');

    % Left panel - Tabbed controls
    tab_panel = uipanel('Parent', fig, ...
                        'Position', [0.02 0.15 0.48 0.8], ...
                        'Title', 'Winding Configuration');

    % Create tabs using button group
    tab_group = uibuttongroup('Parent', tab_panel, ...
                              'Position', [0.02 0.85 0.96 0.12], ...
                              'BorderType', 'none');

    % Tab buttons
    for w = 1:data.n_windings
        uicontrol('Parent', tab_group, 'Style', 'togglebutton', ...
                  'String', data.windings(w).name, ...
                  'Position', [10 + (w-1)*120, 5, 110, 30], ...
                  'Tag', sprintf('tab%d', w), ...
                  'Callback', {@switch_tab, w});
    end

    % Set first tab as selected
    set(findobj(tab_group, 'Tag', 'tab1'), 'Value', 1);

    % Content panels for each winding (initially all hidden)
    for w = 1:data.n_windings
        panel = uipanel('Parent', tab_panel, ...
                        'Position', [0.02 0.02 0.96 0.8], ...
                        'Visible', 'off', ...
                        'Tag', sprintf('content%d', w));

        % Winding name
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', sprintf('%s Winding', data.windings(w).name), ...
                  'Position', [20 380 300 25], ...
                  'FontSize', 12, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        % Number of turns control
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Number of Turns:', ...
                  'Position', [20 330 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_dec_%d', w), ...
                  'Callback', {@adjust_turns, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_turns), ...
                  'Position', [215 330 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('turns_val_%d', w), ...
                  'Callback', {@update_turns_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_inc_%d', w), ...
                  'Callback', {@adjust_turns, w, 1});

        % Number of parallel strands (filar)
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Parallel Strands (Filar):', ...
                  'Position', [20 280 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_dec_%d', w), ...
                  'Callback', {@adjust_filar, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_filar), ...
                  'Position', [215 280 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('filar_val_%d', w), ...
                  'Callback', {@update_filar_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_inc_%d', w), ...
                  'Callback', {@adjust_filar, w, 1});

        % Filar type label
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', get_filar_name(data.windings(w).n_filar), ...
                  'Position', [310 280 150 25], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left', ...
                  'ForegroundColor', [0.2 0.6 0.2], ...
                  'Tag', sprintf('filar_name_%d', w));

        % Current settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'RMS Current (A):', ...
                  'Position', [20 230 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).current), ...
                  'Position', [180 230 80 25], ...
                  'Tag', sprintf('current_%d', w), ...
                  'Callback', {@update_current, w});

        % Phase settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Phase (degrees):', ...
                  'Position', [20 180 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).phase), ...
                  'Position', [180 180 80 25], ...
                  'Tag', sprintf('phase_%d', w), ...
                  'Callback', {@update_phase, w});

        % Summary info
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Configuration Summary:', ...
                  'Position', [20 120 300 20], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
            data.windings(w).n_turns * data.windings(w).n_filar, ...
            data.windings(w).current / data.windings(w).n_filar);

        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', summary_str, ...
                  'Position', [20 60 300 50], ...
                  'HorizontalAlignment', 'left', ...
                  'Tag', sprintf('summary_%d', w));
    end

    % Show first panel
    set(findobj(tab_panel, 'Tag', 'content1'), 'Visible', 'on');

    % Right panel - Visualization
    vis_panel = uipanel('Parent', fig, ...
                        'Position', [0.52 0.15 0.46 0.8], ...
                        'Title', 'Winding Layout Visualization');

    % Axes for visualization
    ax = axes('Parent', vis_panel, ...
              'Position', [0.1 0.1 0.85 0.8], ...
              'Tag', 'vis_axes');

    % Bottom buttons
    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Run Analysis', ...
              'Position', [450 50 150 40], ...
              'FontSize', 12, 'FontWeight', 'bold', ...
              'BackgroundColor', [0.2 0.7 0.3], ...
              'ForegroundColor', 'w', ...
              'Callback', @run_analysis);

    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Reset to Defaults', ...
              'Position', [620 50 150 40], ...
              'FontSize', 11, ...
              'Callback', @reset_defaults);

    % Store data in figure
    guidata(fig, data);
end

function switch_tab(~, ~, tab_num)
    fig = gcbf;
    data = guidata(fig);

    % Hide all content panels
    for w = 1:data.n_windings
        set(findobj(fig, 'Tag', sprintf('content%d', w)), 'Visible', 'off');
    end

    % Show selected panel
    set(findobj(fig, 'Tag', sprintf('content%d', tab_num)), 'Visible', 'on');
end

function adjust_turns(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, data.windings(winding).n_turns + delta);
    data.windings(winding).n_turns = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('turns_val_%d', winding)), 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function adjust_filar(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, min(4, data.windings(winding).n_filar + delta));
    data.windings(winding).n_filar = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('filar_val_%d', winding)), 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_turns_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, new_val);

    data.windings(winding).n_turns = new_val;
    set(src, 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_filar_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, min(4, new_val));

    data.windings(winding).n_filar = new_val;
    set(src, 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_current(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).current = str2double(get(src, 'String'));
    update_summary(fig, data, winding);
    guidata(fig, data);
end

function update_phase(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).phase = str2double(get(src, 'String'));
    guidata(fig, data);
end

function update_summary(fig, data, winding)
    summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
        data.windings(winding).n_turns * data.windings(winding).n_filar, ...
        data.windings(winding).current / data.windings(winding).n_filar);

    set(findobj(fig, 'Tag', sprintf('summary_%d', winding)), 'String', summary_str);
end

function update_visualization(data)
    fig = data.fig_gui;
    ax = findobj(fig, 'Tag', 'vis_axes');

    cla(ax);
    hold(ax, 'on');
    axis(ax, 'equal');
    grid(ax, 'on');

    x_offset = 0;

    for w = 1:data.n_windings
        n_turns = data.windings(w).n_turns;
        n_filar = data.windings(w).n_filar;

        % Calculate winding width
        if n_filar == 1
            winding_width = data.width;
        else
            winding_width = n_filar * data.width + (n_filar - 1) * data.gap_filar;
        end

        % Draw each turn
        for turn = 1:n_turns
            y_pos = (turn - 1) * (data.height + data.gap_layer);

            % Draw filar conductors
            for filar = 1:n_filar
                if n_filar == 1
                    x_pos = x_offset;
                else
                    x_start = x_offset - winding_width/2 + data.width/2;
                    x_pos = x_start + (filar - 1) * (data.width + data.gap_filar);
                end

                % Draw rectangle
                rectangle(ax, 'Position', [x_pos - data.width/2, y_pos, data.width, data.height], ...
                    'FaceColor', data.winding_colors{w}, ...
                    'EdgeColor', 'k', 'LineWidth', 0.5);
            end
        end

        % Add winding label
        max_y = n_turns * (data.height + data.gap_layer);
        text(ax, x_offset, max_y + 0.5e-3, data.windings(w).name, ...
            'HorizontalAlignment', 'center', 'FontWeight', 'bold', ...
            'FontSize', 10, 'Color', data.winding_colors{w});

        % Add info text
        info_str = sprintf('%d turns\n%s', n_turns, get_filar_name(n_filar));
        text(ax, x_offset, -0.8e-3, info_str, ...
            'HorizontalAlignment', 'center', 'FontSize', 8);

        % Move to next winding position
        x_offset = x_offset + winding_width/2 + data.gap_winding + ...
                   (w < data.n_windings) * (data.width * data.windings(w+1).n_filar + ...
                   (data.windings(w+1).n_filar - 1) * data.gap_filar) / 2;
    end

    xlabel(ax, 'X Position (m)');
    ylabel(ax, 'Y Position (m)');
    title(ax, 'Transformer Winding Layout');
    hold(ax, 'off');
end

function run_analysis(~, ~)
    fig = gcbf;
    data = guidata(fig);

    fprintf('\n=== RUNNING ANALYSIS ===\n');

    % Build conductors for all windings
    all_conductors = [];
    all_winding_map = [];
    x_offset = 0;

    for w = 1:data.n_windings
        cfg = struct();
        cfg.n_filar = data.windings(w).n_filar;
        cfg.n_turns = data.windings(w).n_turns;
        cfg.n_windings = 1;
        cfg.width = data.width;
        cfg.height = data.height;
        cfg.gap_layer = data.gap_layer;
        cfg.gap_filar = data.gap_filar;
        cfg.currents = data.windings(w).current;
        cfg.phases = data.windings(w).phase;
        cfg.x_offset = x_offset;

        [cond, map] = build_multifilar_winding(cfg);

        all_conductors = [all_conductors; cond];
        all_winding_map = [all_winding_map; map + (w-1)];

        % Update x_offset for next winding
        if w < data.n_windings
            if cfg.n_filar == 1
                w_width = data.width;
            else
                w_width = cfg.n_filar * data.width + (cfg.n_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + w_width/2 + data.gap_winding;

            next_filar = data.windings(w+1).n_filar;
            if next_filar == 1
                next_width = data.width;
            else
                next_width = next_filar * data.width + (next_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + next_width/2;
        end
    end

    % Build geometry and solve
    fprintf('Building geometry...\n');
    geom = peec_build_geometry(all_conductors, data.sigma, data.mu0, data.Nx, data.Ny, all_winding_map);

    fprintf('Solving at %.0f kHz...\n', data.f/1e3);
    results = peec_solve_frequency(geom, all_conductors, data.f, data.sigma, data.mu0);

    % Display results in new figure
    display_results(data, geom, all_conductors, all_winding_map, results);
end

function display_results(data, geom, conductors, winding_map, results)
    % Create or reuse results figure
    if isempty(data.fig_results) || ~ishandle(data.fig_results)
        data.fig_results = figure('Name', 'Analysis Results', 'Position', [100 50 1400 900]);
    else
        figure(data.fig_results);
        clf;
    end

    % Calculate per-winding losses
    fils_per_cond = data.Nx * data.Ny;
    winding_losses = zeros(data.n_windings, 1);
    winding_Rdc = zeros(data.n_windings, 1);
    winding_Pdc = zeros(data.n_windings, 1);

    cond_offset = 0;
    for w = 1:data.n_windings
        n_cond_in_winding = data.windings(w).n_turns * data.windings(w).n_filar;

        for c = 1:n_cond_in_winding
            idx_start = (cond_offset + c - 1) * fils_per_cond + 1;
            idx_end = (cond_offset + c) * fils_per_cond;
            winding_losses(w) = winding_losses(w) + sum(results.P_fil(idx_start:idx_end));
        end

        cond_offset = cond_offset + n_cond_in_winding;

        % DC loss
        A = data.width * data.height;
        winding_Rdc(w) = (data.windings(w).n_turns / data.windings(w).n_filar) / (data.sigma * A);
        winding_Pdc(w) = 0.5 * data.windings(w).current^2 * winding_Rdc(w);
    end

    % Main title
    annotation('textbox', [0 0.96 1 0.04], ...
        'String', sprintf('Analysis Results @ %.0f kHz', data.f/1e3), ...
        'EdgeColor', 'none', 'HorizontalAlignment', 'center', ...
        'FontSize', 14, 'FontWeight', 'bold');

    % Current density
    subplot(2,3,1);
    plot_current_density(geom, results);
    title('Current Density');

    % Loss density
    subplot(2,3,2);
    plot_loss_density(geom, results);
    title('Loss Density');

    % Per-winding loss comparison
    subplot(2,3,3);
    bar([winding_Pdc, winding_losses]*1e3);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('Loss (mW)');
    legend('DC Loss', 'AC Loss', 'Location', 'best');
    title('Winding Loss Comparison');
    grid on;

    % Rac/Rdc by winding
    subplot(2,3,4);
    rac_rdc = winding_losses ./ winding_Pdc;
    bar(rac_rdc);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('R_{AC}/R_{DC}');
    title('AC Resistance Factor');
    grid on;

    % Summary table
    subplot(2,3,5);
    axis off;

    text(0.05, 0.95, 'Loss Summary', 'FontSize', 12, 'FontWeight', 'bold');
    y_pos = 0.85;

    for w = 1:data.n_windings
        text(0.05, y_pos, sprintf('%s:', data.windings(w).name), ...
            'FontSize', 10, 'FontWeight', 'bold', 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;

        text(0.05, y_pos, sprintf('  Config: %d turns, %s', ...
            data.windings(w).n_turns, get_filar_name(data.windings(w).n_filar)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  DC Loss: %.4f W', winding_Pdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  AC Loss: %.4f W', winding_losses(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  Rac/Rdc: %.2f', rac_rdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.12;
    end

    text(0.05, y_pos, sprintf('Total Loss: %.4f W', results.P_total), ...
        'FontSize', 11, 'FontWeight', 'bold');

    % Configuration visualization
    subplot(2,3,6);
    axis off;
    text(0.05, 0.95, 'Configuration', 'FontSize', 12, 'FontWeight', 'bold');

    y_pos = 0.85;
    for w = 1:data.n_windings
        filar_str = get_filar_name(data.windings(w).n_filar);
        text(0.05, y_pos, sprintf('%s: %d × %s', ...
            data.windings(w).name, data.windings(w).n_turns, filar_str), ...
            'FontSize', 9, 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;
    end

    fprintf('\n=== ANALYSIS COMPLETE ===\n');
    fprintf('Total loss: %.6f W\n', results.P_total);
end

function reset_defaults(~, ~)
    close all;
    interactive_winding_designer();
end

function name = get_filar_name(n)
    names = {'Single-filar', 'Bi-filar', 'Tri-filar', 'Quad-filar'};
    name = names{n};
end




% interactive_winding_designer.m
% Interactive GUI for designing multi-filar transformer windings

function interactive_winding_designer()

    close all;

    % Initialize global data structure
    data = struct();

    % Default transformer configuration
    data.n_windings = 2;
    data.winding_names = {'Primary', 'Secondary'};
    data.winding_colors = {[0.2 0.4 0.8], [0.8 0.2 0.2]};

    % Default winding parameters
    data.windings(1).name = 'Primary';
    data.windings(1).n_turns = 10;
    data.windings(1).n_filar = 1;
    data.windings(1).current = 10;
    data.windings(1).phase = 0;

    data.windings(2).name = 'Secondary';
    data.windings(2).n_turns = 5;
    data.windings(2).n_filar = 1;
    data.windings(2).current = 5;
    data.windings(2).phase = 180;

    % Geometry parameters
    data.width = 2e-3;
    data.height = 1e-3;
    data.gap_layer = 0.2e-3;
    data.gap_filar = 0.15e-3;
    data.gap_winding = 1e-3;

    % Analysis parameters
    data.sigma = 5.8e7;
    data.mu0 = 4*pi*1e-7;
    data.f = 100e3;
    data.Nx = 6;
    data.Ny = 6;

    % Create main GUI figure
    data.fig_gui = figure('Name', 'Interactive Winding Designer', ...
                          'Position', [50 100 1200 700], ...
                          'NumberTitle', 'off', ...
                          'MenuBar', 'none', ...
                          'Resize', 'off');

    % Create results figure (initially hidden)
    data.fig_results = [];

    % Build GUI layout
    build_gui(data);

    % Initial visualization
    update_visualization(data);
end

function build_gui(data)

    fig = data.fig_gui;

    % Main title
    uicontrol('Parent', fig, 'Style', 'text', ...
              'String', 'Interactive Transformer Winding Designer', ...
              'Position', [20 660 1160 30], ...
              'FontSize', 14, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center');

    % Left panel - Tabbed controls
    tab_panel = uipanel('Parent', fig, ...
                        'Position', [0.02 0.15 0.48 0.8], ...
                        'Title', 'Winding Configuration');

    % Create tabs using button group
    tab_group = uibuttongroup('Parent', tab_panel, ...
                              'Position', [0.02 0.85 0.96 0.12], ...
                              'BorderType', 'none');

    % Tab buttons
    for w = 1:data.n_windings
        uicontrol('Parent', tab_group, 'Style', 'togglebutton', ...
                  'String', data.windings(w).name, ...
                  'Position', [10 + (w-1)*120, 5, 110, 30], ...
                  'Tag', sprintf('tab%d', w), ...
                  'Callback', {@switch_tab, w});
    end

    % Set first tab as selected
    set(findobj(tab_group, 'Tag', 'tab1'), 'Value', 1);

    % Content panels for each winding (initially all hidden)
    for w = 1:data.n_windings
        panel = uipanel('Parent', tab_panel, ...
                        'Position', [0.02 0.02 0.96 0.8], ...
                        'Visible', 'off', ...
                        'Tag', sprintf('content%d', w));

        % Winding name
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', sprintf('%s Winding', data.windings(w).name), ...
                  'Position', [20 380 300 25], ...
                  'FontSize', 12, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        % Number of turns control
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Number of Turns:', ...
                  'Position', [20 330 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_dec_%d', w), ...
                  'Callback', {@adjust_turns, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_turns), ...
                  'Position', [215 330 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('turns_val_%d', w), ...
                  'Callback', {@update_turns_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_inc_%d', w), ...
                  'Callback', {@adjust_turns, w, 1});

        % Number of parallel strands (filar)
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Parallel Strands (Filar):', ...
                  'Position', [20 280 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_dec_%d', w), ...
                  'Callback', {@adjust_filar, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_filar), ...
                  'Position', [215 280 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('filar_val_%d', w), ...
                  'Callback', {@update_filar_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_inc_%d', w), ...
                  'Callback', {@adjust_filar, w, 1});

        % Filar type label
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', get_filar_name(data.windings(w).n_filar), ...
                  'Position', [310 280 150 25], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left', ...
                  'ForegroundColor', [0.2 0.6 0.2], ...
                  'Tag', sprintf('filar_name_%d', w));

        % Current settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'RMS Current (A):', ...
                  'Position', [20 230 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).current), ...
                  'Position', [180 230 80 25], ...
                  'Tag', sprintf('current_%d', w), ...
                  'Callback', {@update_current, w});

        % Phase settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Phase (degrees):', ...
                  'Position', [20 180 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).phase), ...
                  'Position', [180 180 80 25], ...
                  'Tag', sprintf('phase_%d', w), ...
                  'Callback', {@update_phase, w});

        % Summary info
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Configuration Summary:', ...
                  'Position', [20 120 300 20], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
            data.windings(w).n_turns * data.windings(w).n_filar, ...
            data.windings(w).current / data.windings(w).n_filar);

        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', summary_str, ...
                  'Position', [20 60 300 50], ...
                  'HorizontalAlignment', 'left', ...
                  'Tag', sprintf('summary_%d', w));
    end

    % Show first panel
    set(findobj(tab_panel, 'Tag', 'content1'), 'Visible', 'on');

    % Right panel - Visualization
    vis_panel = uipanel('Parent', fig, ...
                        'Position', [0.52 0.15 0.46 0.8], ...
                        'Title', 'Winding Layout Visualization');

    % Axes for visualization
    ax = axes('Parent', vis_panel, ...
              'Position', [0.1 0.1 0.85 0.8], ...
              'Tag', 'vis_axes');

    % Bottom buttons
    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Run Analysis', ...
              'Position', [450 50 150 40], ...
              'FontSize', 12, 'FontWeight', 'bold', ...
              'BackgroundColor', [0.2 0.7 0.3], ...
              'ForegroundColor', 'w', ...
              'Callback', @run_analysis);

    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Reset to Defaults', ...
              'Position', [620 50 150 40], ...
              'FontSize', 11, ...
              'Callback', @reset_defaults);

    % Store data in figure
    guidata(fig, data);
end

function switch_tab(~, ~, tab_num)
    fig = gcbf;
    data = guidata(fig);

    % Hide all content panels
    for w = 1:data.n_windings
        set(findobj(fig, 'Tag', sprintf('content%d', w)), 'Visible', 'off');
    end

    % Show selected panel
    set(findobj(fig, 'Tag', sprintf('content%d', tab_num)), 'Visible', 'on');
end

function adjust_turns(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, data.windings(winding).n_turns + delta);
    data.windings(winding).n_turns = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('turns_val_%d', winding)), 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function adjust_filar(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, min(4, data.windings(winding).n_filar + delta));
    data.windings(winding).n_filar = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('filar_val_%d', winding)), 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_turns_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, new_val);

    data.windings(winding).n_turns = new_val;
    set(src, 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_filar_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, min(4, new_val));

    data.windings(winding).n_filar = new_val;
    set(src, 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_current(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).current = str2double(get(src, 'String'));
    update_summary(fig, data, winding);
    guidata(fig, data);
end

function update_phase(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).phase = str2double(get(src, 'String'));
    guidata(fig, data);
end

function update_summary(fig, data, winding)
    summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
        data.windings(winding).n_turns * data.windings(winding).n_filar, ...
        data.windings(winding).current / data.windings(winding).n_filar);

    set(findobj(fig, 'Tag', sprintf('summary_%d', winding)), 'String', summary_str);
end

function update_visualization(data)
    fig = data.fig_gui;
    ax = findobj(fig, 'Tag', 'vis_axes');

    cla(ax);
    hold(ax, 'on');
    axis(ax, 'equal');
    grid(ax, 'on');

    x_offset = 0;

    for w = 1:data.n_windings
        n_turns = data.windings(w).n_turns;
        n_filar = data.windings(w).n_filar;

        % Calculate winding width (n_filar columns)
        if n_filar == 1
            winding_width = data.width;
        else
            winding_width = n_filar * data.width + (n_filar - 1) * data.gap_filar;
        end

        % VERTICAL-FIRST LAYOUT: Each column gets all turns stacked vertically
        for column = 1:n_filar

            % Calculate x position for this column
            if n_filar == 1
                x_pos = x_offset;
            else
                x_start = x_offset - winding_width/2 + data.width/2;
                x_pos = x_start + (column - 1) * (data.width + data.gap_filar);
            end

            % Stack all turns vertically in this column
            for turn = 1:n_turns
                y_pos = (turn - 1) * (data.height + data.gap_layer);

                % Draw rectangle for this conductor
                rectangle(ax, 'Position', [x_pos - data.width/2, y_pos, data.width, data.height], ...
                    'FaceColor', data.winding_colors{w}, ...
                    'EdgeColor', 'k', 'LineWidth', 0.5);

                % Add turn number on first column only
                if column == 1
                    text(ax, x_pos - data.width/2 - 0.3e-3, y_pos + data.height/2, ...
                        sprintf('T%d', turn), 'FontSize', 7, ...
                        'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle');
                end
            end

            % Add column label at top
            max_y = n_turns * (data.height + data.gap_layer);
            if n_filar > 1
                text(ax, x_pos, max_y + 0.3e-3, sprintf('Col %d', column), ...
                    'HorizontalAlignment', 'center', 'FontSize', 7, ...
                    'Color', data.winding_colors{w});
            end
        end

        % Add winding label
        max_y = n_turns * (data.height + data.gap_layer);
        text(ax, x_offset, max_y + 0.8e-3, data.windings(w).name, ...
            'HorizontalAlignment', 'center', 'FontWeight', 'bold', ...
            'FontSize', 10, 'Color', data.winding_colors{w});

        % Add info text
        info_str = sprintf('%d turns × %d col\n%s', n_turns, n_filar, get_filar_name(n_filar));
        text(ax, x_offset, -1.2e-3, info_str, ...
            'HorizontalAlignment', 'center', 'FontSize', 8);

        % Move to next winding position
        if w < data.n_windings
            % Calculate next winding width
            next_filar = data.windings(w+1).n_filar;
            if next_filar == 1
                next_width = data.width;
            else
                next_width = next_filar * data.width + (next_filar - 1) * data.gap_filar;
            end

            x_offset = x_offset + winding_width/2 + data.gap_winding + next_width/2;
        end
    end

    xlabel(ax, 'X Position (m)');
    ylabel(ax, 'Y Position (m)');
    title(ax, 'Transformer Winding Layout (Vertical-First Fill)');
    hold(ax, 'off');
end

function run_analysis(~, ~)
    fig = gcbf;
    data = guidata(fig);

    fprintf('\n=== RUNNING ANALYSIS ===\n');

    % Build conductors for all windings
    all_conductors = [];
    all_winding_map = [];
    x_offset = 0;

    for w = 1:data.n_windings
        cfg = struct();
        cfg.n_filar = data.windings(w).n_filar;
        cfg.n_turns = data.windings(w).n_turns;
        cfg.n_windings = 1;
        cfg.width = data.width;
        cfg.height = data.height;
        cfg.gap_layer = data.gap_layer;
        cfg.gap_filar = data.gap_filar;
        cfg.currents = data.windings(w).current;
        cfg.phases = data.windings(w).phase;
        cfg.x_offset = x_offset;

        [cond, map] = build_multifilar_winding(cfg);

        all_conductors = [all_conductors; cond];
        all_winding_map = [all_winding_map; map + (w-1)];

        % Update x_offset for next winding
        if w < data.n_windings
            if cfg.n_filar == 1
                w_width = data.width;
            else
                w_width = cfg.n_filar * data.width + (cfg.n_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + w_width/2 + data.gap_winding;

            next_filar = data.windings(w+1).n_filar;
            if next_filar == 1
                next_width = data.width;
            else
                next_width = next_filar * data.width + (next_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + next_width/2;
        end
    end

    % Build geometry and solve
    fprintf('Building geometry...\n');
    geom = peec_build_geometry(all_conductors, data.sigma, data.mu0, data.Nx, data.Ny, all_winding_map);

    fprintf('Solving at %.0f kHz...\n', data.f/1e3);
    results = peec_solve_frequency(geom, all_conductors, data.f, data.sigma, data.mu0);

    % Display results in new figure
    display_results(data, geom, all_conductors, all_winding_map, results);
end

function display_results(data, geom, conductors, winding_map, results)
    % Create or reuse results figure
    if isempty(data.fig_results) || ~ishandle(data.fig_results)
        data.fig_results = figure('Name', 'Analysis Results', 'Position', [100 50 1400 900]);
    else
        figure(data.fig_results);
        clf;
    end

    % Calculate per-winding losses
    fils_per_cond = data.Nx * data.Ny;
    winding_losses = zeros(data.n_windings, 1);
    winding_Rdc = zeros(data.n_windings, 1);
    winding_Pdc = zeros(data.n_windings, 1);

    cond_offset = 0;
    for w = 1:data.n_windings
        n_cond_in_winding = data.windings(w).n_turns * data.windings(w).n_filar;

        for c = 1:n_cond_in_winding
            idx_start = (cond_offset + c - 1) * fils_per_cond + 1;
            idx_end = (cond_offset + c) * fils_per_cond;
            winding_losses(w) = winding_losses(w) + sum(results.P_fil(idx_start:idx_end));
        end

        cond_offset = cond_offset + n_cond_in_winding;

        % DC loss
        A = data.width * data.height;
        winding_Rdc(w) = (data.windings(w).n_turns / data.windings(w).n_filar) / (data.sigma * A);
        winding_Pdc(w) = 0.5 * data.windings(w).current^2 * winding_Rdc(w);
    end

    % Main title
    annotation('textbox', [0 0.96 1 0.04], ...
        'String', sprintf('Analysis Results @ %.0f kHz', data.f/1e3), ...
        'EdgeColor', 'none', 'HorizontalAlignment', 'center', ...
        'FontSize', 14, 'FontWeight', 'bold');

    % Current density
    subplot(2,3,1);
    plot_current_density(geom, results);
    title('Current Density');

    % Loss density
    subplot(2,3,2);
    plot_loss_density(geom, results);
    title('Loss Density');

    % Per-winding loss comparison
    subplot(2,3,3);
    bar([winding_Pdc, winding_losses]*1e3);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('Loss (mW)');
    legend('DC Loss', 'AC Loss', 'Location', 'best');
    title('Winding Loss Comparison');
    grid on;

    % Rac/Rdc by winding
    subplot(2,3,4);
    rac_rdc = winding_losses ./ winding_Pdc;
    bar(rac_rdc);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('R_{AC}/R_{DC}');
    title('AC Resistance Factor');
    grid on;

    % Summary table
    subplot(2,3,5);
    axis off;

    text(0.05, 0.95, 'Loss Summary', 'FontSize', 12, 'FontWeight', 'bold');
    y_pos = 0.85;

    for w = 1:data.n_windings
        text(0.05, y_pos, sprintf('%s:', data.windings(w).name), ...
            'FontSize', 10, 'FontWeight', 'bold', 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;

        text(0.05, y_pos, sprintf('  Config: %d turns, %s', ...
            data.windings(w).n_turns, get_filar_name(data.windings(w).n_filar)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  DC Loss: %.4f W', winding_Pdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  AC Loss: %.4f W', winding_losses(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  Rac/Rdc: %.2f', rac_rdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.12;
    end

    text(0.05, y_pos, sprintf('Total Loss: %.4f W', results.P_total), ...
        'FontSize', 11, 'FontWeight', 'bold');

    % Configuration visualization
    subplot(2,3,6);
    axis off;
    text(0.05, 0.95, 'Configuration', 'FontSize', 12, 'FontWeight', 'bold');

    y_pos = 0.85;
    for w = 1:data.n_windings
        filar_str = get_filar_name(data.windings(w).n_filar);
        text(0.05, y_pos, sprintf('%s: %d × %s', ...
            data.windings(w).name, data.windings(w).n_turns, filar_str), ...
            'FontSize', 9, 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;
    end

    fprintf('\n=== ANALYSIS COMPLETE ===\n');
    fprintf('Total loss: %.6f W\n', results.P_total);
end

function reset_defaults(~, ~)
    close all;
    interactive_winding_designer();
end

function name = get_filar_name(n)
    names = {'Single-filar', 'Bi-filar', 'Tri-filar', 'Quad-filar'};
    name = names{n};
end
%}

% interactive_winding_designer.m
% Interactive GUI for designing multi-filar transformer windings

function interactive_winding_designer()

    close all;

    % Initialize global data structure
    data = struct();

    % Default transformer configuration
    data.n_windings = 2;
    data.winding_names = {'Primary', 'Secondary'};
    data.winding_colors = {[0.2 0.4 0.8], [0.8 0.2 0.2]};

    % Default winding parameters
    data.windings(1).name = 'Primary';
    data.windings(1).n_turns = 10;
    data.windings(1).n_filar = 1;
    data.windings(1).current = 10;
    data.windings(1).phase = 0;

    data.windings(2).name = 'Secondary';
    data.windings(2).n_turns = 5;
    data.windings(2).n_filar = 1;
    data.windings(2).current = 5;
    data.windings(2).phase = 180;

    % Geometry parameters
    data.width = 2e-3;
    data.height = 1e-3;
    data.gap_layer = 0.2e-3;
    data.gap_filar = 0.15e-3;
    data.gap_winding = 1e-3;

    % Analysis parameters
    data.sigma = 5.8e7;
    data.mu0 = 4*pi*1e-7;
    data.f = 100e3;
    data.Nx = 6;
    data.Ny = 6;

    % Create main GUI figure
    data.fig_gui = figure('Name', 'Interactive Winding Designer', ...
                          'Position', [50 100 1200 700], ...
                          'NumberTitle', 'off', ...
                          'MenuBar', 'none', ...
                          'Resize', 'off');

    % Create results figure (initially hidden)
    data.fig_results = [];

    % Build GUI layout
    build_gui(data);

    % Initial visualization
    update_visualization(data);
end

function build_gui(data)

    fig = data.fig_gui;

    % Main title
    uicontrol('Parent', fig, 'Style', 'text', ...
              'String', 'Interactive Transformer Winding Designer', ...
              'Position', [20 660 1160 30], ...
              'FontSize', 14, 'FontWeight', 'bold', ...
              'HorizontalAlignment', 'center');

    % Left panel - Tabbed controls
    tab_panel = uipanel('Parent', fig, ...
                        'Position', [0.02 0.15 0.48 0.8], ...
                        'Title', 'Winding Configuration');

    % Create tabs using button group
    tab_group = uibuttongroup('Parent', tab_panel, ...
                              'Position', [0.02 0.85 0.96 0.12], ...
                              'BorderType', 'none');

    % Tab buttons
    for w = 1:data.n_windings
        uicontrol('Parent', tab_group, 'Style', 'togglebutton', ...
                  'String', data.windings(w).name, ...
                  'Position', [10 + (w-1)*120, 5, 110, 30], ...
                  'Tag', sprintf('tab%d', w), ...
                  'Callback', {@switch_tab, w});
    end

    % Set first tab as selected
    set(findobj(tab_group, 'Tag', 'tab1'), 'Value', 1);

    % Content panels for each winding (initially all hidden)
    for w = 1:data.n_windings
        panel = uipanel('Parent', tab_panel, ...
                        'Position', [0.02 0.02 0.96 0.8], ...
                        'Visible', 'off', ...
                        'Tag', sprintf('content%d', w));

        % Winding name
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', sprintf('%s Winding', data.windings(w).name), ...
                  'Position', [20 380 300 25], ...
                  'FontSize', 12, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        % Number of turns control
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Number of Turns:', ...
                  'Position', [20 330 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_dec_%d', w), ...
                  'Callback', {@adjust_turns, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_turns), ...
                  'Position', [215 330 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('turns_val_%d', w), ...
                  'Callback', {@update_turns_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 330 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('turns_inc_%d', w), ...
                  'Callback', {@adjust_turns, w, 1});

        % Number of parallel strands (filar)
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Parallel Strands (Filar):', ...
                  'Position', [20 280 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '−', ...
                  'Position', [180 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_dec_%d', w), ...
                  'Callback', {@adjust_filar, w, -1});

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).n_filar), ...
                  'Position', [215 280 50 25], ...
                  'FontSize', 11, ...
                  'HorizontalAlignment', 'center', ...
                  'Tag', sprintf('filar_val_%d', w), ...
                  'Callback', {@update_filar_manual, w});

        uicontrol('Parent', panel, 'Style', 'pushbutton', ...
                  'String', '+', ...
                  'Position', [270 280 30 25], ...
                  'FontSize', 14, ...
                  'Tag', sprintf('filar_inc_%d', w), ...
                  'Callback', {@adjust_filar, w, 1});

        % Filar type label
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', get_filar_name(data.windings(w).n_filar), ...
                  'Position', [310 280 150 25], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left', ...
                  'ForegroundColor', [0.2 0.6 0.2], ...
                  'Tag', sprintf('filar_name_%d', w));

        % Current settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'RMS Current (A):', ...
                  'Position', [20 230 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).current), ...
                  'Position', [180 230 80 25], ...
                  'Tag', sprintf('current_%d', w), ...
                  'Callback', {@update_current, w});

        % Phase settings
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Phase (degrees):', ...
                  'Position', [20 180 150 20], ...
                  'HorizontalAlignment', 'left');

        uicontrol('Parent', panel, 'Style', 'edit', ...
                  'String', num2str(data.windings(w).phase), ...
                  'Position', [180 180 80 25], ...
                  'Tag', sprintf('phase_%d', w), ...
                  'Callback', {@update_phase, w});

        % Summary info
        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', 'Configuration Summary:', ...
                  'Position', [20 120 300 20], ...
                  'FontSize', 10, 'FontWeight', 'bold', ...
                  'HorizontalAlignment', 'left');

        summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
            data.windings(w).n_turns * data.windings(w).n_filar, ...
            data.windings(w).current / data.windings(w).n_filar);

        uicontrol('Parent', panel, 'Style', 'text', ...
                  'String', summary_str, ...
                  'Position', [20 60 300 50], ...
                  'HorizontalAlignment', 'left', ...
                  'Tag', sprintf('summary_%d', w));
    end

    % Show first panel
    set(findobj(tab_panel, 'Tag', 'content1'), 'Visible', 'on');

    % Right panel - Visualization
    vis_panel = uipanel('Parent', fig, ...
                        'Position', [0.52 0.15 0.46 0.8], ...
                        'Title', 'Winding Layout Visualization');

    % Axes for visualization
    ax = axes('Parent', vis_panel, ...
              'Position', [0.1 0.1 0.85 0.8], ...
              'Tag', 'vis_axes');

    % Bottom buttons
    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Run Analysis', ...
              'Position', [450 50 150 40], ...
              'FontSize', 12, 'FontWeight', 'bold', ...
              'BackgroundColor', [0.2 0.7 0.3], ...
              'ForegroundColor', 'w', ...
              'Callback', @run_analysis);

    uicontrol('Parent', fig, 'Style', 'pushbutton', ...
              'String', 'Reset to Defaults', ...
              'Position', [620 50 150 40], ...
              'FontSize', 11, ...
              'Callback', @reset_defaults);

    % Store data in figure
    guidata(fig, data);
end

function switch_tab(~, ~, tab_num)
    fig = gcbf;
    data = guidata(fig);

    % Hide all content panels
    for w = 1:data.n_windings
        set(findobj(fig, 'Tag', sprintf('content%d', w)), 'Visible', 'off');
    end

    % Show selected panel
    set(findobj(fig, 'Tag', sprintf('content%d', tab_num)), 'Visible', 'on');
end

function adjust_turns(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, data.windings(winding).n_turns + delta);
    data.windings(winding).n_turns = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('turns_val_%d', winding)), 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function adjust_filar(~, ~, winding, delta)
    fig = gcbf;
    data = guidata(fig);

    new_val = max(1, min(4, data.windings(winding).n_filar + delta));
    data.windings(winding).n_filar = new_val;

    % Update display
    set(findobj(fig, 'Tag', sprintf('filar_val_%d', winding)), 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_turns_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, new_val);

    data.windings(winding).n_turns = new_val;
    set(src, 'String', num2str(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_filar_manual(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    new_val = round(str2double(get(src, 'String')));
    new_val = max(1, min(4, new_val));

    data.windings(winding).n_filar = new_val;
    set(src, 'String', num2str(new_val));
    set(findobj(fig, 'Tag', sprintf('filar_name_%d', winding)), 'String', get_filar_name(new_val));
    update_summary(fig, data, winding);

    guidata(fig, data);
    update_visualization(data);
end

function update_current(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).current = str2double(get(src, 'String'));
    update_summary(fig, data, winding);
    guidata(fig, data);
end

function update_phase(src, ~, winding)
    fig = gcbf;
    data = guidata(fig);

    data.windings(winding).phase = str2double(get(src, 'String'));
    guidata(fig, data);
end

function update_summary(fig, data, winding)
    summary_str = sprintf('Total conductors: %d\nCurrent per strand: %.2f A', ...
        data.windings(winding).n_turns * data.windings(winding).n_filar, ...
        data.windings(winding).current / data.windings(winding).n_filar);

    set(findobj(fig, 'Tag', sprintf('summary_%d', winding)), 'String', summary_str);
end

function update_visualization(data)
    fig = data.fig_gui;
    ax = findobj(fig, 'Tag', 'vis_axes');

    cla(ax);
    hold(ax, 'on');
    axis(ax, 'equal');
    grid(ax, 'on');

    x_offset = 0;
    max_y_all = 0;

    for w = 1:data.n_windings
        n_turns = data.windings(w).n_turns;
        n_filar = data.windings(w).n_filar;

        % Winding is just one column (all parallel strands stack vertically)
        winding_width = data.width;
        x_pos = x_offset;

        % Draw each turn with stacked parallel strands
        y_offset = 0;

        for turn = 1:n_turns

            % Stack parallel strands vertically for this turn
            for strand = 1:n_filar

                % Y position for this strand
                y_pos = y_offset + (strand - 1) * (data.height + data.gap_filar);

                % Draw rectangle for this conductor
                rectangle(ax, 'Position', [x_pos - data.width/2, y_pos, data.width, data.height], ...
                    'FaceColor', data.winding_colors{w}, ...
                    'EdgeColor', 'k', 'LineWidth', 0.5);

                % Add strand indicator for multi-filar
                if n_filar > 1 && strand > 1
                    % Draw small line connecting parallel strands
                    plot(ax, [x_pos + data.width/2 + 0.05e-3, x_pos + data.width/2 + 0.15e-3], ...
                        [y_pos + data.height/2, y_pos + data.height/2], ...
                        'Color', data.winding_colors{w}, 'LineWidth', 2);
                end
            end

            % Add turn label on the left
            turn_center_y = y_offset + (n_filar * data.height + (n_filar-1) * data.gap_filar) / 2;
            text(ax, x_pos - data.width/2 - 0.3e-3, turn_center_y, ...
                sprintf('T%d', turn), 'FontSize', 7, ...
                'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle');

            % Add filar count indicator on the right for first turn
            if turn == 1 && n_filar > 1
                text(ax, x_pos + data.width/2 + 0.25e-3, turn_center_y, ...
                    sprintf('%d×', n_filar), 'FontSize', 7, ...
                    'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
                    'Color', data.winding_colors{w}, 'FontWeight', 'bold');
            end

            % Move to next turn position
            turn_height = n_filar * data.height + (n_filar - 1) * data.gap_filar + data.gap_layer;
            y_offset = y_offset + turn_height;
        end

        % Track maximum y for scaling
        max_y_all = max(max_y_all, y_offset);

        % Add winding label at top
        text(ax, x_pos, y_offset + 0.5e-3, data.windings(w).name, ...
            'HorizontalAlignment', 'center', 'FontWeight', 'bold', ...
            'FontSize', 10, 'Color', data.winding_colors{w});

        % Add info text at bottom
        info_str = sprintf('%d turns\n%s', n_turns, get_filar_name(n_filar));
        text(ax, x_pos, -1.2e-3, info_str, ...
            'HorizontalAlignment', 'center', 'FontSize', 8);

        % Move to next winding position
        if w < data.n_windings
            x_offset = x_offset + data.width/2 + data.gap_winding + data.width/2;
        end
    end

    % Set axis limits with 1.5x Y expansion
    ylim(ax, [-1.5e-3, max_y_all * 1.5]);

    xlabel(ax, 'X Position (m)');
    ylabel(ax, 'Y Position (m)');
    title(ax, 'Transformer Winding Layout (Parallel Strands Stack Vertically)');
    hold(ax, 'off');
end

function run_analysis(~, ~)
    fig = gcbf;
    data = guidata(fig);

    fprintf('\n=== RUNNING ANALYSIS ===\n');

    % Build conductors for all windings
    all_conductors = [];
    all_winding_map = [];
    x_offset = 0;

    for w = 1:data.n_windings
        cfg = struct();
        cfg.n_filar = data.windings(w).n_filar;
        cfg.n_turns = data.windings(w).n_turns;
        cfg.n_windings = 1;
        cfg.width = data.width;
        cfg.height = data.height;
        cfg.gap_layer = data.gap_layer;
        cfg.gap_filar = data.gap_filar;
        cfg.currents = data.windings(w).current;
        cfg.phases = data.windings(w).phase;
        cfg.x_offset = x_offset;

        [cond, map] = build_multifilar_winding(cfg);

        all_conductors = [all_conductors; cond];
        all_winding_map = [all_winding_map; map + (w-1)];

        % Update x_offset for next winding
        if w < data.n_windings
            if cfg.n_filar == 1
                w_width = data.width;
            else
                w_width = cfg.n_filar * data.width + (cfg.n_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + w_width/2 + data.gap_winding;

            next_filar = data.windings(w+1).n_filar;
            if next_filar == 1
                next_width = data.width;
            else
                next_width = next_filar * data.width + (next_filar - 1) * data.gap_filar;
            end
            x_offset = x_offset + next_width/2;
        end
    end

    % Build geometry and solve
    fprintf('Building geometry...\n');
    geom = peec_build_geometry(all_conductors, data.sigma, data.mu0, data.Nx, data.Ny, all_winding_map);

    fprintf('Solving at %.0f kHz...\n', data.f/1e3);
    results = peec_solve_frequency(geom, all_conductors, data.f, data.sigma, data.mu0);

    % Display results in new figure
    display_results(data, geom, all_conductors, all_winding_map, results);
end

function display_results(data, geom, conductors, winding_map, results)
    % Create or reuse results figure
    if isempty(data.fig_results) || ~ishandle(data.fig_results)
        data.fig_results = figure('Name', 'Analysis Results', 'Position', [100 50 1400 900]);
    else
        figure(data.fig_results);
        clf;
    end

    % Calculate per-winding losses
    fils_per_cond = data.Nx * data.Ny;
    winding_losses = zeros(data.n_windings, 1);
    winding_Rdc = zeros(data.n_windings, 1);
    winding_Pdc = zeros(data.n_windings, 1);

    cond_offset = 0;
    for w = 1:data.n_windings
        n_cond_in_winding = data.windings(w).n_turns * data.windings(w).n_filar;

        for c = 1:n_cond_in_winding
            idx_start = (cond_offset + c - 1) * fils_per_cond + 1;
            idx_end = (cond_offset + c) * fils_per_cond;
            winding_losses(w) = winding_losses(w) + sum(results.P_fil(idx_start:idx_end));
        end

        cond_offset = cond_offset + n_cond_in_winding;

        % DC loss
        A = data.width * data.height;
        winding_Rdc(w) = (data.windings(w).n_turns / data.windings(w).n_filar) / (data.sigma * A);
        winding_Pdc(w) = 0.5 * data.windings(w).current^2 * winding_Rdc(w);
    end

    % Main title
    annotation('textbox', [0 0.96 1 0.04], ...
        'String', sprintf('Analysis Results @ %.0f kHz', data.f/1e3), ...
        'EdgeColor', 'none', 'HorizontalAlignment', 'center', ...
        'FontSize', 14, 'FontWeight', 'bold');

    % Current density
    subplot(2,3,1);
    plot_current_density(geom, results);
    title('Current Density');

    % Loss density
    subplot(2,3,2);
    plot_loss_density(geom, results);
    title('Loss Density');

    % Per-winding loss comparison
    subplot(2,3,3);
    bar([winding_Pdc, winding_losses]*1e3);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('Loss (mW)');
    legend('DC Loss', 'AC Loss', 'Location', 'best');
    title('Winding Loss Comparison');
    grid on;

    % Rac/Rdc by winding
    subplot(2,3,4);
    rac_rdc = winding_losses ./ winding_Pdc;
    bar(rac_rdc);
    set(gca, 'XTickLabel', {data.windings.name});
    ylabel('R_{AC}/R_{DC}');
    title('AC Resistance Factor');
    grid on;

    % Summary table
    subplot(2,3,5);
    axis off;

    text(0.05, 0.95, 'Loss Summary', 'FontSize', 12, 'FontWeight', 'bold');
    y_pos = 0.85;

    for w = 1:data.n_windings
        text(0.05, y_pos, sprintf('%s:', data.windings(w).name), ...
            'FontSize', 10, 'FontWeight', 'bold', 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;

        text(0.05, y_pos, sprintf('  Config: %d turns, %s', ...
            data.windings(w).n_turns, get_filar_name(data.windings(w).n_filar)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  DC Loss: %.4f W', winding_Pdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  AC Loss: %.4f W', winding_losses(w)), 'FontSize', 9);
        y_pos = y_pos - 0.07;

        text(0.05, y_pos, sprintf('  Rac/Rdc: %.2f', rac_rdc(w)), 'FontSize', 9);
        y_pos = y_pos - 0.12;
    end

    text(0.05, y_pos, sprintf('Total Loss: %.4f W', results.P_total), ...
        'FontSize', 11, 'FontWeight', 'bold');

    % Configuration visualization
    subplot(2,3,6);
    axis off;
    text(0.05, 0.95, 'Configuration', 'FontSize', 12, 'FontWeight', 'bold');

    y_pos = 0.85;
    for w = 1:data.n_windings
        filar_str = get_filar_name(data.windings(w).n_filar);
        text(0.05, y_pos, sprintf('%s: %d × %s', ...
            data.windings(w).name, data.windings(w).n_turns, filar_str), ...
            'FontSize', 9, 'Color', data.winding_colors{w});
        y_pos = y_pos - 0.08;
    end

    fprintf('\n=== ANALYSIS COMPLETE ===\n');
    fprintf('Total loss: %.6f W\n', results.P_total);
end

function reset_defaults(~, ~)
    close all;
    interactive_winding_designer();
end

function name = get_filar_name(n)
    names = {'Single-filar', 'Bi-filar', 'Tri-filar', 'Quad-filar'};
    name = names{n};
end
