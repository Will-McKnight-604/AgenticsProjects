% build_multifilar_winding.m
% Build multi-filar winding configurations (bi-filar, tri-filar, quad-filar)
%{
function [conductors, winding_map] = build_multifilar_winding(config)
% Build multi-filar winding configuration
%
% INPUT:
%   config - Structure with fields:
%     .n_filar      - Number of parallel conductors (1=single, 2=bifilar, 3=trifilar, 4=quadfilar)
%     .n_turns      - Total number of turns per winding
%     .n_windings   - Number of separate windings (e.g., 2 for transformer)
%     .width        - Conductor width (m)
%     .height       - Conductor height (m)
%     .gap_layer    - Gap between layers (m)
%     .gap_filar    - Gap between filar conductors within a turn (m)
%     .gap_winding  - Gap between different windings in x-direction (m)
%     .currents     - [n_windings × 1] Current magnitude for each winding (Arms)
%     .phases       - [n_windings × 1] Phase angle for each winding (degrees)
%     .x_offset     - [n_windings × 1] X-position offset for each winding (m)
%
% OUTPUT:
%   conductors   - [N × 6] array: [x, y, width, height, current, phase]
%   winding_map  - [N × 1] array: which winding each conductor belongs to

    % ========== VALIDATE INPUTS ==========
    required_fields = {'n_filar', 'n_turns', 'n_windings', 'width', 'height', ...
                       'gap_layer', 'currents', 'phases'};

    for i = 1:length(required_fields)
        if ~isfield(config, required_fields{i})
            error('Missing required field: %s', required_fields{i});
        end
    end

    % Set defaults
    if ~isfield(config, 'gap_filar')
        config.gap_filar = config.gap_layer;  % Default: same as layer gap
    end

    if ~isfield(config, 'gap_winding')
        config.gap_winding = config.width + 1e-3;  % Default: 1mm gap
    end

    if ~isfield(config, 'x_offset')
        % Auto-calculate x positions for each winding
        config.x_offset = zeros(config.n_windings, 1);
        for w = 2:config.n_windings
            config.x_offset(w) = config.x_offset(w-1) + config.gap_winding;
        end
    end

    % Validate n_filar
    if config.n_filar < 1 || config.n_filar > 4
        error('n_filar must be 1, 2, 3, or 4');
    end

    % ========== BUILD CONDUCTORS ==========
    conductors = [];
    winding_map = [];

    for w = 1:config.n_windings

        x_base = config.x_offset(w);
        I_mag = config.currents(w);
        phase = config.phases(w);

        for turn = 1:config.n_turns

            % Calculate y position for this turn
            y_pos = (turn - 1) * (config.height + config.gap_layer);

            % Add filar conductors for this turn
            for filar = 1:config.n_filar

                % Calculate x position for this filar conductor
                if config.n_filar == 1
                    % Single conductor - centered
                    x_pos = x_base;
                else
                    % Multiple conductors - spread horizontally
                    total_width = config.n_filar * config.width + ...
                                  (config.n_filar - 1) * config.gap_filar;
                    x_start = x_base - total_width/2 + config.width/2;
                    x_pos = x_start + (filar - 1) * (config.width + config.gap_filar);
                end

                % Add conductor
                % Current is divided equally among filar conductors
                I_filar = I_mag / config.n_filar;

                conductors = [conductors; ...
                    x_pos, y_pos, config.width, config.height, I_filar, phase];

                winding_map = [winding_map; w];
            end
        end
    end

    % ========== SUMMARY ==========
    fprintf('Multi-filar winding configuration:\n');
    fprintf('  Configuration: %d-filar\n', config.n_filar);
    fprintf('  Number of windings: %d\n', config.n_windings);
    fprintf('  Turns per winding: %d\n', config.n_turns);
    fprintf('  Total conductors: %d\n', size(conductors, 1));

    for w = 1:config.n_windings
        n_cond_in_winding = sum(winding_map == w);
        fprintf('  Winding %d: %d conductors, %.2f A total (%.2f A per filar)\n', ...
            w, n_cond_in_winding, config.currents(w), config.currents(w)/config.n_filar);
    end
end
%}

% build_multifilar_winding.m
% Build multi-filar winding configurations
% Fills vertically first, then adds horizontal columns when Y-limit reached
%{
function [conductors, winding_map] = build_multifilar_winding(config)
% Build multi-filar winding configuration
%
% INPUT:
%   config - Structure with fields:
%     .n_filar      - Number of parallel strands (1-4)
%     .n_turns      - Total number of turns per winding
%     .n_windings   - Number of separate windings (e.g., 2 for transformer)
%     .width        - Conductor width (m)
%     .height       - Conductor height (m)
%     .gap_layer    - Gap between vertical layers (m)
%     .gap_filar    - Gap between horizontal filar columns (m)
%     .gap_winding  - Gap between different windings in x-direction (m)
%     .currents     - [n_windings × 1] Current magnitude for each winding (Arms)
%     .phases       - [n_windings × 1] Phase angle for each winding (degrees)
%     .x_offset     - [n_windings × 1] X-position offset for each winding (m)
%     .max_y        - (optional) Maximum Y extent before starting new column (m)
%
% OUTPUT:
%   conductors   - [N × 6] array: [x, y, width, height, current, phase]
%   winding_map  - [N × 1] array: which winding each conductor belongs to
%
% LAYOUT STRATEGY (vertical-first filling):
%   Column 1: All n_turns stacked vertically (up to max_y)
%   Column 2: All n_turns stacked vertically (if n_filar >= 2)
%   Column 3: All n_turns stacked vertically (if n_filar >= 3)
%   Column 4: All n_turns stacked vertically (if n_filar >= 4)

    % ========== VALIDATE INPUTS ==========
    required_fields = {'n_filar', 'n_turns', 'n_windings', 'width', 'height', ...
                       'gap_layer', 'currents', 'phases'};

    for i = 1:length(required_fields)
        if ~isfield(config, required_fields{i})
            error('Missing required field: %s', required_fields{i});
        end
    end

    % Set defaults
    if ~isfield(config, 'gap_filar')
        config.gap_filar = config.gap_layer;  % Default: same as layer gap
    end

    if ~isfield(config, 'gap_winding')
        config.gap_winding = config.width + 1e-3;  % Default: 1mm gap
    end

    if ~isfield(config, 'x_offset')
        config.x_offset = zeros(config.n_windings, 1);
    end

    if ~isfield(config, 'max_y')
        % Default: allow all turns in one column (no Y limit)
        config.max_y = inf;
    end

    % Validate n_filar
    if config.n_filar < 1 || config.n_filar > 4
        error('n_filar must be 1, 2, 3, or 4');
    end

    % ========== BUILD CONDUCTORS ==========
    conductors = [];
    winding_map = [];

    for w = 1:config.n_windings

        x_base = config.x_offset(w);
        I_mag = config.currents(w);
        phase = config.phases(w);

        % Current is divided equally among all filar strands
        I_filar = I_mag / config.n_filar;

        % Layout strategy: Fill vertically first, then add columns
        % Each column contains all turns stacked vertically

        for column = 1:config.n_filar

            % Calculate x position for this column
            if config.n_filar == 1
                % Single column - centered
                x_pos = x_base;
            else
                % Multiple columns - spread horizontally from center
                total_width = config.n_filar * config.width + ...
                              (config.n_filar - 1) * config.gap_filar;
                x_start = x_base - total_width/2 + config.width/2;
                x_pos = x_start + (column - 1) * (config.width + config.gap_filar);
            end

            % Fill this column vertically with all turns
            for turn = 1:config.n_turns

                % Calculate y position for this turn
                y_pos = (turn - 1) * (config.height + config.gap_layer);

                % Check if we've exceeded Y limit
                if y_pos > config.max_y
                    % In future: could implement wrapping to new column
                    % For now: just continue (unlimited Y)
                end

                % Add conductor
                conductors = [conductors; ...
                    x_pos, y_pos, config.width, config.height, I_filar, phase];

                winding_map = [winding_map; w];
            end
        end
    end

    % ========== SUMMARY ==========
    fprintf('Multi-filar winding configuration:\n');
    fprintf('  Configuration: %d-filar (%d columns)\n', config.n_filar, config.n_filar);
    fprintf('  Number of windings: %d\n', config.n_windings);
    fprintf('  Turns per winding: %d\n', config.n_turns);
    fprintf('  Layout: %d columns × %d turns (vertical-first fill)\n', ...
        config.n_filar, config.n_turns);
    fprintf('  Total conductors: %d\n', size(conductors, 1));

    for w = 1:config.n_windings
        n_cond_in_winding = sum(winding_map == w);
        fprintf('  Winding %d: %d conductors, %.2f A total (%.2f A per column)\n', ...
            w, n_cond_in_winding, config.currents(w), I_filar);
    end
end


% build_multifilar_winding.m
% Build multi-filar winding configurations
% Fills vertically first, then adds horizontal columns when Y-limit reached

function [conductors, winding_map] = build_multifilar_winding(config)
% Build multi-filar winding configuration
%
% INPUT:
%   config - Structure with fields:
%     .n_filar      - Number of parallel strands (1-4)
%     .n_turns      - Total number of turns per winding
%     .n_windings   - Number of separate windings (e.g., 2 for transformer)
%     .width        - Conductor width (m)
%     .height       - Conductor height (m)
%     .gap_layer    - Gap between vertical layers (m)
%     .gap_filar    - Gap between horizontal filar columns (m)
%     .gap_winding  - Gap between different windings in x-direction (m)
%     .currents     - [n_windings × 1] Current magnitude for each winding (Arms)
%     .phases       - [n_windings × 1] Phase angle for each winding (degrees)
%     .x_offset     - [n_windings × 1] X-position offset for each winding (m)
%     .max_y        - (optional) Maximum Y extent before starting new column (m)
%
% OUTPUT:
%   conductors   - [N × 6] array: [x, y, width, height, current, phase]
%   winding_map  - [N × 1] array: which winding each conductor belongs to
%
% LAYOUT STRATEGY (vertical-first filling):
%   Column 1: All n_turns stacked vertically (up to max_y)
%   Column 2: All n_turns stacked vertically (if n_filar >= 2)
%   Column 3: All n_turns stacked vertically (if n_filar >= 3)
%   Column 4: All n_turns stacked vertically (if n_filar >= 4)

    % ========== VALIDATE INPUTS ==========
    required_fields = {'n_filar', 'n_turns', 'n_windings', 'width', 'height', ...
                       'gap_layer', 'currents', 'phases'};

    for i = 1:length(required_fields)
        if ~isfield(config, required_fields{i})
            error('Missing required field: %s', required_fields{i});
        end
    end

    % Set defaults
    if ~isfield(config, 'gap_filar')
        config.gap_filar = config.gap_layer;  % Default: same as layer gap
    end

    if ~isfield(config, 'gap_winding')
        config.gap_winding = config.width + 1e-3;  % Default: 1mm gap
    end

    if ~isfield(config, 'x_offset')
        config.x_offset = zeros(config.n_windings, 1);
    end

    if ~isfield(config, 'max_y')
        % Default: allow all turns in one column (no Y limit)
        config.max_y = inf;
    end

    % Validate n_filar
    if config.n_filar < 1 || config.n_filar > 4
        error('n_filar must be 1, 2, 3, or 4');
    end

    % ========== BUILD CONDUCTORS ==========
    conductors = [];
    winding_map = [];

    for w = 1:config.n_windings

        x_base = config.x_offset(w);
        I_mag = config.currents(w);
        phase = config.phases(w);

        % Current is divided equally among all filar strands
        I_filar = I_mag / config.n_filar;

        % Layout strategy: Fill vertically first, then add columns
        % Each column contains all turns stacked vertically

        for column = 1:config.n_filar

            % Calculate x position for this column
            if config.n_filar == 1
                % Single column - centered
                x_pos = x_base;
            else
                % Multiple columns - spread horizontally from center
                total_width = config.n_filar * config.width + ...
                              (config.n_filar - 1) * config.gap_filar;
                x_start = x_base - total_width/2 + config.width/2;
                x_pos = x_start + (column - 1) * (config.width + config.gap_filar);
            end

            % Fill this column vertically with all turns
            for turn = 1:config.n_turns

                % Calculate y position for this turn
                y_pos = (turn - 1) * (config.height + config.gap_layer);

                % Check if we've exceeded Y limit
                if y_pos > config.max_y
                    % In future: could implement wrapping to new column
                    % For now: just continue (unlimited Y)
                end

                % Add conductor
                conductors = [conductors; ...
                    x_pos, y_pos, config.width, config.height, I_filar, phase];

                winding_map = [winding_map; w];
            end
        end
    end

    % ========== SUMMARY ==========
    fprintf('Multi-filar winding configuration:\n');
    fprintf('  Configuration: %d-filar (%d columns)\n', config.n_filar, config.n_filar);
    fprintf('  Number of windings: %d\n', config.n_windings);
    fprintf('  Turns per winding: %d\n', config.n_turns);
    fprintf('  Layout: %d columns × %d turns (vertical-first fill)\n', ...
        config.n_filar, config.n_turns);
    fprintf('  Total conductors: %d\n', size(conductors, 1));

    for w = 1:config.n_windings
        n_cond_in_winding = sum(winding_map == w);
        fprintf('  Winding %d: %d conductors, %.2f A total (%.2f A per column)\n', ...
            w, n_cond_in_winding, config.currents(w), I_filar);
    end
end
%}

% build_multifilar_winding.m
% Build multi-filar winding configurations
% Fills vertically first, then adds horizontal columns when Y-limit reached

function [conductors, winding_map] = build_multifilar_winding(config)
% Build multi-filar winding configuration
%
% INPUT:
%   config - Structure with fields:
%     .n_filar      - Number of parallel strands (1-4)
%     .n_turns      - Total number of turns per winding
%     .n_windings   - Number of separate windings (e.g., 2 for transformer)
%     .width        - Conductor width (m)
%     .height       - Conductor height (m)
%     .gap_layer    - Gap between vertical layers (m)
%     .gap_filar    - Gap between horizontal filar columns (m)
%     .gap_winding  - Gap between different windings in x-direction (m)
%     .currents     - [n_windings × 1] Current magnitude for each winding (Arms)
%     .phases       - [n_windings × 1] Phase angle for each winding (degrees)
%     .x_offset     - [n_windings × 1] X-position offset for each winding (m)
%     .max_y        - (optional) Maximum Y extent before starting new column (m)
%
% OUTPUT:
%   conductors   - [N × 6] array: [x, y, width, height, current, phase]
%   winding_map  - [N × 1] array: which winding each conductor belongs to
%
% LAYOUT STRATEGY (vertical-first filling):
%   Column 1: All n_turns stacked vertically (up to max_y)
%   Column 2: All n_turns stacked vertically (if n_filar >= 2)
%   Column 3: All n_turns stacked vertically (if n_filar >= 3)
%   Column 4: All n_turns stacked vertically (if n_filar >= 4)

    % ========== VALIDATE INPUTS ==========
    required_fields = {'n_filar', 'n_turns', 'n_windings', 'width', 'height', ...
                       'gap_layer', 'currents', 'phases'};

    for i = 1:length(required_fields)
        if ~isfield(config, required_fields{i})
            error('Missing required field: %s', required_fields{i});
        end
    end

    % Set defaults
    if ~isfield(config, 'gap_filar')
        config.gap_filar = config.gap_layer;  % Default: same as layer gap
    end

    if ~isfield(config, 'gap_winding')
        config.gap_winding = config.width + 1e-3;  % Default: 1mm gap
    end

    if ~isfield(config, 'x_offset')
        config.x_offset = zeros(config.n_windings, 1);
    end

    if ~isfield(config, 'max_y')
        % Default: allow all turns in one column (no Y limit)
        config.max_y = inf;
    end

    % Validate n_filar
    if config.n_filar < 1 || config.n_filar > 4
        error('n_filar must be 1, 2, 3, or 4');
    end

    % ========== BUILD CONDUCTORS ==========
    conductors = [];
    winding_map = [];

    for w = 1:config.n_windings

        x_base = config.x_offset(w);
        I_mag = config.currents(w);
        phase = config.phases(w);

        % Current is divided equally among all filar strands
        I_filar = I_mag / config.n_filar;

        % Layout strategy: Fill vertically first, then add columns
        % Each column contains all turns stacked vertically

        for column = 1:config.n_filar

            % Calculate x position for this column
            if config.n_filar == 1
                % Single column - centered
                x_pos = x_base;
            else
                % Multiple columns - spread horizontally from center
                total_width = config.n_filar * config.width + ...
                              (config.n_filar - 1) * config.gap_filar;
                x_start = x_base - total_width/2 + config.width/2;
                x_pos = x_start + (column - 1) * (config.width + config.gap_filar);
            end

            % Fill this column vertically with all turns
            for turn = 1:config.n_turns

                % Calculate y position for this turn
                y_pos = (turn - 1) * (config.height + config.gap_layer);

                % Check if we've exceeded Y limit
                if y_pos > config.max_y
                    % In future: could implement wrapping to new column
                    % For now: just continue (unlimited Y)
                end

                % Add conductor
                conductors = [conductors; ...
                    x_pos, y_pos, config.width, config.height, I_filar, phase];

                winding_map = [winding_map; w];
            end
        end
    end

    % ========== SUMMARY ==========
    fprintf('Multi-filar winding configuration:\n');
    fprintf('  Configuration: %d-filar (%d columns)\n', config.n_filar, config.n_filar);
    fprintf('  Number of windings: %d\n', config.n_windings);
    fprintf('  Turns per winding: %d\n', config.n_turns);
    fprintf('  Layout: %d columns × %d turns (vertical-first fill)\n', ...
        config.n_filar, config.n_turns);
    fprintf('  Total conductors: %d\n', size(conductors, 1));

    for w = 1:config.n_windings
        n_cond_in_winding = sum(winding_map == w);
        fprintf('  Winding %d: %d conductors, %.2f A total (%.2f A per column)\n', ...
            w, n_cond_in_winding, config.currents(w), I_filar);
    end
end
